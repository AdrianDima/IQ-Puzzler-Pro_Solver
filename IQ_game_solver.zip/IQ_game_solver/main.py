#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 10 22:39:35 2025

@author: adrian
"""

# Import module
import tkinter as tk

# Create object
root = tk.Tk()
root.title("IQ game solver")

w = 1350
h = 1070
# set minimum window size value
root.minsize(w, h)
# set maximum window size value
root.maxsize(w, h)

# center a window on the screen:
def center_window(window):
    window.update_idletasks()
    width = window.winfo_width()
    height = window.winfo_height()
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2
    window.geometry(f"{width}x{height}+{x}+{y}")

center_window(root)

# Create four frames for buttons:
frame_top = tk.Frame(root, bg='lightblue', bd=3, cursor='hand2',
                              highlightcolor='red', highlightthickness=2, highlightbackground='black', 
                              relief=tk.RAISED)
frame_top.pack(pady=10)
   
frame_up = tk.Frame(root, bg='dark sea green', bd=3, cursor='hand2',
                              highlightcolor='red', highlightthickness=2, highlightbackground='black', 
                              relief=tk.RAISED)
frame_up.pack(pady=10)

frame_middle = tk.Frame(root, bg='dark sea green', bd=3, cursor='hand2',
                              highlightcolor='red', highlightthickness=2, highlightbackground='black', 
                              relief=tk.RAISED)
frame_middle.pack(pady=0)

frame_down = tk.Frame(root, cursor='hand2',
                              relief=tk.RAISED)
frame_down.pack(pady=10)



from IQ_game_solver import *
game = Game()
# n - number of shapes
n = len(game.ss.shapes)
# all shapes colors:
colors = []
for index in range(n):
    color = game.ss.shapes[index].color
    colors.append(color)

# colors checked by clicking with the mouse on the board:
checked_colors = []

import os
cwd = os.getcwd()
photos = []
for color in colors:
    color_file = "shape_" + color + ".png"
    # photo = os.sep.join([cwd, color_file])
    photo = os.sep.join([cwd, "pictures", color_file])
    photos.append(tk.PhotoImage(file = photo))


# Creating the button "info" with specified options:
btn_info = tk.Button(frame_top, text = 'info', command = lambda: infoCommand())
# Set the position of button
btn_info.pack(side=tk.LEFT, padx=10, pady=10)

def infoCommand():
    
    window = tk.Toplevel()
    window.wm_title("")
    
    w = 550
    h = 1430

    window.minsize(w, h)
    window.maxsize(w, h)
    
    center_window(window)
    
    frame = tk.Frame(window)
    frame.pack(pady = 10)
    
    s = "How this game is played:"    
    title = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    title.config(font =("TkDefaultFont", 12))
    title.pack(side=tk.TOP)
    
    
    image = "IQ_physical_game.png"
    path = os.sep.join([cwd, "pictures", image])
    photo = tk.PhotoImage(file = path)
    image1 = tk.Label(frame, image = photo)
    image1.photo = photo
    image1.pack(side=tk.TOP)
    
    s = "Choose a challenge. Place the puzzle \
pieces as indicated. Try to fill the empty spaces with all the \
remaining puzzle pieces. There are 40 challenges, starting with \
a simple one like this:"
    
    text1 = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    text1.config(font =("TkDefaultFont", 10))
    text1.pack(side=tk.TOP)
    
    image = "Game_1.png"
    path = os.sep.join([cwd, "pictures", image])
    photo = tk.PhotoImage(file = path)    
    image2 = tk.Label(frame, image = photo)
    image2.photo = photo
    image2.pack(side=tk.TOP)


    s = "and ending with one like this that has only two pieces placed on \
the board at the beginning:"
    
    text2 = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    text2.config(font =("TkDefaultFont", 10))
    text2.pack(side=tk.TOP)    
    
    image = "Game_40.png"
    path = os.sep.join([cwd, "pictures", image])
    photo = tk.PhotoImage(file = path)    
    image3 = tk.Label(frame, image = photo)
    image3.photo = photo
    image3.pack(side=tk.TOP)    

    btn_ok = tk.Button(window, text = "OK", command = window.destroy)
    btn_ok.pack(padx = 10, pady = 10)


# Creating the button "User guide" with specified options:
btn_user_guide = tk.Button(frame_top, text = 'User guide', command = lambda: userGuideCommand())
# Set the position of button
btn_user_guide.pack(side=tk.LEFT, padx=10, pady=10)

def userGuideCommand():
    
    window = tk.Toplevel()
    window.wm_title("")
    
    w = 550
    h = 1600

    window.minsize(w, h)
    window.maxsize(w, h)
    
    center_window(window)
    
    frame = tk.Frame(window)
    frame.pack(pady = 10)

    s = "If the player wants to define his own starting configuration, \
he has no way of knowing if this one has a solution. This solver was \
created for this purpose.\n\
\n\
How to use this solver:\n\
Click the button corresponding to the piece you want to place on the board. \
Click by click defines the chosen piece on the board. \
If you put a ball wrong, you can use the \"ball clear\" button. \
The \"input check\" button checks the correctness of all the pieces on the board. \
The picture below shows three such wrong piece positions on the board:"


    text1 = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    text1.config(font =("TkDefaultFont", 10))
    text1.pack(side=tk.TOP)

    image = "wrong_positions.png"
    path = os.sep.join([cwd, "pictures", image])
    photo = tk.PhotoImage(file = path)
    image1 = tk.Label(frame, image = photo)
    image1.photo = photo
    image1.pack(side=tk.TOP)
    
    s = "However, this version of the solver does not check configurations like \
the one below, where both pieces are correctly defined and yet the configuration is wrong:"

    text2 = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    text2.config(font =("TkDefaultFont", 10))
    text2.pack(side=tk.TOP)
    
    image = "wrong_positions_in_between_shapes.png"
    path = os.sep.join([cwd, "pictures", image])
    photo = tk.PhotoImage(file = path)
    image2 = tk.Label(frame, image = photo)
    image2.photo = photo
    image2.pack(side=tk.TOP)    
    
    s = "The \"Solve\" button is only activated when everything is OK upon exiting the \
\"input check\" command.\
\n\n\
The solver running time esimations:\n\
4 pieces on the board: within a minute\n\
3 pieces on the board: within 7 minutes\n\
2 pieces on the board: about 21 minutes\n\
For a single piece on the board, the running time is around 3 hours..."
    
    text3 = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", wraplength=530, justify="left")
    text3.config(font =("TkDefaultFont", 10))
    text3.pack(side=tk.TOP)    
    
    btn_ok = tk.Button(window, text = "OK", command = window.destroy)
    btn_ok.pack(padx = 10, pady = 10)


# create shape buttons:
index = 0
for photo in photos:
    frame = frame_middle
    if index < 6:
        frame = frame_up
    # By defining a temporary variable temp, the value of that
    # var gets fixed at the moment when the button is defined:
    button = tk.Button(frame, image = photo, command = lambda temp = index : shapeButton(temp))
    button.pack(side=tk.LEFT, padx=10, pady=10)
    index += 1
    
shape_index = 0
clear = False

def shapeButton(index):
    global shape_index
    shape_index = index
    global clear
    clear = False


# create ball buttons:
rows = game.solution.board.boardH
columns = game.solution.board.boardW
tempBoard = np.full( (rows, columns), None )


def ballButtonChange(n):
    # function to get the index and the identity (button name)
    button = button_identities[n]
    row = n // columns
    col = n % columns
    btn_check["state"] = "normal"
    if clear:
        dot = os.sep.join([cwd, "pictures", "dot_.png"])
        tempBoard[row][col] = None
        
        count = 0
        for r in range(rows):
            for c in range(columns):
                if tempBoard[r][c] != None:
                    count += 1
        if count == 0:
            btn_check["state"] = "disabled"    

    else:
        color = "dot_" + colors[shape_index] + ".png"
        dot = os.sep.join([cwd, "pictures", color])
        tempBoard[row][col] = shape_index
    photo = tk.PhotoImage(file = dot)
    button.configure(image = photo)
    button.photo = photo
    btn_solve["state"] = "disabled"

from functools import partial
button_identities = []
dot = os.sep.join([cwd, "pictures", "dot_.png"])
photo = tk.PhotoImage(file = dot)
i = 0
for row in range(rows):
    frame = tk.Frame(root, cursor='hand2', relief=tk.RAISED)
    frame.pack(pady=0)
    for col in range(columns):
        button = tk.Button(frame, image = photo, command = partial(ballButtonChange, i))
        button.pack(side=tk.LEFT)
        # add the button's identity to a list:
        button_identities.append(button)
        i += 1


frame_bottom_buttons = tk.Frame(root, bg='lightblue', bd=3, cursor='hand2',
                              highlightcolor='red', highlightthickness=2, highlightbackground='black', 
                              relief=tk.RAISED)
frame_bottom_buttons.pack(pady=20)

# Creating the button "clear" with specified options
btn_clear = tk.Button(frame_bottom_buttons, text = 'ball clear', command = lambda: clearCommand())
# Set the position of button
btn_clear.pack(side=tk.LEFT, padx=10, pady=10)

def clearCommand():
    global clear
    clear = True
    btn_solve["state"] = "disabled"

# Creating the button "wipe" with specified options
btn_wipe = tk.Button(frame_bottom_buttons, text = 'wipe the table', 
                     command = lambda: wipeCommand())
# Set the position of button
btn_wipe.pack(side=tk.LEFT, padx=10, pady=10)

def wipeCommand():
    dot = os.sep.join([cwd, "pictures", "dot_.png"])
    photo = tk.PhotoImage(file = dot)
    for button in button_identities:
        button.configure(image = photo)
        button.photo = photo
    for r in range(rows):
        for c in range(columns):
            tempBoard[r][c] = None
    btn_check["state"] = "disabled"
    btn_solve["state"] = "disabled"
   

# Creating the button "input check" with specified options
btn_check = tk.Button(frame_bottom_buttons, text = 'input check', 
                      command = lambda: inputCheckCommand(), state = "disabled")
# Set the position of button
btn_check.pack(side=tk.LEFT, padx=10, pady=10)

global currentShapesOnTheBoard
currentShapesOnTheBoard = []

def inputCheckCommand():
    global currentShapesOnTheBoard
    currentShapesOnTheBoard.clear()
    
    current_shapes = currentShapes()
    NoErrors = True
    
    for index in current_shapes:
        ok, shape, row, col = checkShapeFromBoard(index, current_shapes[index])
        if not ok:
            NoErrors = False
            popupWindowError(colors[index], "wrong shape")
        else:
            shape.id = index
            if not game.solution.board.checkParticularPositions(shape, row, col):
                NoErrors = False
                popupWindowError(colors[index], "wrong position")
            else:
                currentShapesOnTheBoard.append([shape, row, col])
    
    if NoErrors:
        popupWindowOK(len(current_shapes))

    
def currentShapes():
    current_shapes = {}
    for r in range(rows):
        for c in range(columns):
            if tempBoard[r][c] != None:
                current_shapes.setdefault(tempBoard[r][c], []).append([r, c])
    return current_shapes

def checkForInterruptions(values):
    v = sorted(values)
    for i in range(len(v) - 1):
        if abs(v[i] - v[i + 1]) > 1:
            return True
    return False

# check the shape of the piece:
def checkShapeFromBoard(index, balls):
    if len(balls) != game.ss.shapes[index].numberOfBalls():
        return False, None, None, None
    x = [ball[1] for ball in balls] # x means columns
    y = [ball[0] for ball in balls] # y means rows
    if checkForInterruptions(x) or checkForInterruptions(y):
        return False, None, None, None
    
    minX = min(x)
    minY = min(y)
    
    row = max(y)

    # "translates" the shape to the upper left corner of the board:
    for ball in balls:
        ball[0] -= minY
        ball[1] -= minX
        
    # reverses the sens of the vertical axis:
    y = [ball[0] for ball in balls]
    maxY = max(y)
    for ball in balls:
        ball[0] = maxY - ball[0]
    
    # translates the shape into the shape csys:
    for ball in balls:
        temp = ball[0]
        ball[0] = ball[1]
        ball[1] = temp
    
    shape = checkShapeStructure(index, balls)
    if not shape:
        return False, None, None, None
    else:
        return True, shape, row + shape.minY // 100, minX - shape.minX // 100


def checkShapeStructure(index, balls):

    # create a temp shape with this balls and color:
    tempShape = Shape()
    # remove the default [0, 0] ball:
    tempShape.balls.pop()
    
    for ball in balls:
        tempShape.addBall(100 * ball[0], 100 * ball[1])
    tempShape.color(colors[index])
    
    found = False
    possiblePositions = Solution().shapePositions(game.ss.shapes[index])
    for shapePos in possiblePositions:
        shapeCopy = copy.deepcopy(shapePos)
        shapeCopy.extremeCoordinates()
        shapeCopy.firstQuadrantTranslate()
        if shapeCopy == tempShape:
            tempShape = shapePos
            found = True
            break
    
    if found:
        tempShape.extremeCoordinates()
        return tempShape
    else:
        return None


def popupWindowError(color, problem):
    
    window = tk.Toplevel()
    window.wm_title("")
    
    w = 1300
    h = 150

    window.minsize(w, h)
    window.maxsize(w, h)
    
    center_window(window)
    
    frame = tk.Frame(window)
    frame.pack(pady = 10)
    
    msgbody1 = tk.Label(frame, text = "The shape ")
    msgbody1.config(font =("TkDefaultFont", 14))
    msgbody1.pack(side=tk.LEFT)
    
    msgbody2 = tk.Label(frame, text = color, fg = color)
    msgbody2.config(font =("TkDefaultFont", 14, "bold"))
    msgbody2.pack(side=tk.LEFT)
    
    msg = " has a wrong position on the board."
    if problem == "wrong shape":
        msg = " is wrong."
    msgbody3 = tk.Label(frame, text = msg)
    msgbody3.config(font =("TkDefaultFont", 14))
    msgbody3.pack(side=tk.LEFT)

    btn_ok = tk.Button(window, text = "OK", command = window.destroy)
    btn_ok.pack(padx = 10, pady = 10)
    

def popupWindowOK(n):
    
    window = tk.Toplevel()
    window.wm_title("")
    
    w = 550
    h = 260

    window.minsize(w, h)
    window.maxsize(w, h)
    
    center_window(window)
    
    frame = tk.Frame(window)
    frame.pack(pady = 10)
    
    s = "All " + str(n) + " pieces on the board are correctly defined.\n\
This configuration may have a solution.\n\
You can run the solver."

    text = tk.Label(frame, bg='dark sea green', bd=3, text = s, anchor="w", 
                    wraplength=530, justify="left")
    text.config(font =("TkDefaultFont", 10))
    text.pack(side=tk.TOP)

    btn_ok = tk.Button(window, text = "OK", command = window.destroy)
    btn_ok.pack(padx = 10, pady = 10)

    btn_solve["state"] = "normal"


# Creating the button "solve" with specified options
btn_solve = tk.Button(frame_bottom_buttons, text = 'Solve', 
                      command = lambda: solveCommand(), state = "disabled")
# Set the position of button
btn_solve.pack(side=tk.LEFT, padx=10, pady=10)

import time
def solveCommand():
    for item in currentShapesOnTheBoard:
        game.insertShape(None, item[0], False, 0, item[1], item[2])

    root.destroy()
    
    start_time = time.time()
    game.solve()
    print("Running time: %s seconds" % round((time.time() - start_time), 1))
    
    game.drawSolution()

# Execute tkinter
root.mainloop()


