#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""
#file  -- ShapeStorage.py --

from Shape import *

class ShapeStorage:
    
    def __init__(self, n):
        self.shapes = []
        for _ in range(n):
            self.shapes.append(Shape())
        
        # O
        # O
        # OO
        self.shapes[0].addBall(100, 0)
        self.shapes[0].addBall(0, 100)
        self.shapes[0].addBall(0, 200)
        self.shapes[0].symmetrical = False
        self.shapes[0].color("dark blue")
        
        # OO
        # O
        # OO
        self.shapes[1].addBall(100, 0)
        self.shapes[1].addBall(0, 100)
        self.shapes[1].addBall(0, 200)
        self.shapes[1].addBall(100, 200)
        self.shapes[1].color("green yellow")
    
        # O
        # O
        # O
        # OO
        self.shapes[2].addBall(100, 0)
        self.shapes[2].addBall(0, 100)
        self.shapes[2].addBall(0, 200)
        self.shapes[2].addBall(0, 300)
        self.shapes[2].symmetrical = False
        self.shapes[2].color("red")
        
        # O
        # O
        # OOO
        self.shapes[3].addBall(100, 0)
        self.shapes[3].addBall(200, 0)
        self.shapes[3].addBall(0, 100)
        self.shapes[3].addBall(0, 200)
        self.shapes[3].color("deep sky blue")
        
        #  O
        # OOO
        self.shapes[4].addBall(100, 0)
        self.shapes[4].addBall(200, 0)
        self.shapes[4].addBall(100, 100)
        self.shapes[4].color("teal")
        
        #   O
        #  OO
        # OO
        self.shapes[5].addBall(100, 0)
        self.shapes[5].addBall(100, 100)
        self.shapes[5].addBall(200, 100)
        self.shapes[5].addBall(200, 200)
        self.shapes[5].color("indigo")
        
        # OO
        # OOO
        self.shapes[6].addBall(100, 0)
        self.shapes[6].addBall(0, 100)
        self.shapes[6].addBall(100, 100)
        self.shapes[6].addBall(200, 0)
        self.shapes[6].symmetrical = False
        self.shapes[6].color("medium aquamarine")
        
        # O
        # OO
        self.shapes[7].addBall(100, 0)
        self.shapes[7].addBall(0, 100)
        self.shapes[7].color("sky blue")
        
        #  O
        #  OO
        # OO
        self.shapes[8].addBall(100, 0)
        self.shapes[8].addBall(100, 100)
        self.shapes[8].addBall(200, 100)
        self.shapes[8].addBall(100, 200)
        self.shapes[8].symmetrical = False
        self.shapes[8].color("dark orange")
        
        #  OO
        # OO
        self.shapes[9].addBall(100, 0)
        self.shapes[9].addBall(100, 100)
        self.shapes[9].addBall(200, 100)
        self.shapes[9].symmetrical = False
        self.shapes[9].color("brown")
        
        #  O
        # OOOO
        self.shapes[10].addBall(100, 0)
        self.shapes[10].addBall(100, 100)
        self.shapes[10].addBall(200, 0)
        self.shapes[10].addBall(300, 0)
        self.shapes[10].symmetrical = False
        self.shapes[10].color("gold")
        
        #  OOO
        # OO
        self.shapes[11].addBall(100, 0)
        self.shapes[11].addBall(100, 100)
        self.shapes[11].addBall(200, 100)
        self.shapes[11].addBall(300, 100)
        self.shapes[11].symmetrical = False
        self.shapes[11].color("hot pink")