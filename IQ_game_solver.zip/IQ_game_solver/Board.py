#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""
#file  -- Board.py -

import numpy as np

class Board:
    
    def __init__(self):
        self.boardW = 11
        self.boardH = 5
        self.board = np.full( (self.boardH, self.boardW), False )
    
    
    # check the board boundaries:
    def checkBoard(self, shape, row, col):
        if shape.maxY / 100 > row or \
            abs( shape.minY / 100 ) > self.boardH - row - 1 or \
            abs( shape.minX / 100 ) > col or \
            shape.maxX / 100 + col > self.boardW - 1:
            return False
        return True


    # check adjacent cells for overlap:
    def checkAdjacentCellsForOverlap(self, shape, row, col):
        for ball in shape.balls:
            rowCurr = int(row - ball[1] / 100)
            colCurr = int(col + ball[0] / 100)
            if self.board[rowCurr][colCurr]:
                return False
        return True

 
    def checkPos(self, shape, row, col):
        shape.extremeCoordinates()
        if not self.checkBoard(shape, row, col):
            return False
        if not self.checkAdjacentCellsForOverlap(shape, row, col):
            return False
        if not self.checkParticularPositions(shape, row, col):
            return False
        return True

    # counter = 0
    # check corner positions and other impossible positions:
    def checkParticularPositions(self, shape, row, col):
        
        # the table origin is the upper left corner
        minRow = int(row - shape.maxY / 100) # maxY >= 0
        minCol = int(col + shape.minX / 100) # minX <= 0
        maxRow = int(row - shape.minY / 100) # minY <= 0
        maxCol = int(col + shape.maxX / 100) # maxX >= 0
        
        # check L shapes:
        if shape.id in [0, 2, 3, 7]:
            if row != 0 and row != self.boardH - 1 and \
               col != 0 and col != self.boardW - 1:
                    if minCol == 0 or maxCol == self.boardW - 1 and \
                      (minRow == 0 or maxRow == self.boardH - 1):
                          return False
                      
        # check this shape:
        # OO
        # O
        # OO
        if shape.id == 1:
            if (row == self.boardH - 2 and maxRow == self.boardH - 1) or \
               (row == 1 and minRow == 0) or \
               (col == 1 and minCol == 0) or \
               (col == self.boardW - 2 and maxCol == self.boardW - 1):
                   return False

                
        # check this shape:
        # O
        # O
        # O
        # OO
        if shape.id == 2:
            # initial position or mirrored and rotated with 180:
            # two special cases (parallel with the left column):
            if shape.maxX == 100:
                if minCol == 1:
                    return False              

            # rotated with 90 or mirrored and rotated with 270:
            # corner cases and two special cases (parallel with the top row):
            if shape.minY == -100:
                if minRow == 1 and (minCol == 0 or maxCol == self.boardW - 1):
                    return False
               
                
            # rotated with 180 or mirrored, unrotated:
            # corner cases and two special cases (parallel with the right column):
            if shape.minX == -100:
                if maxCol == self.boardW - 2:
                    return False
               
                  
            # rotated with 270 or mirrored and rotated with 180:
            # corner cases and two special cases (parallel with the bottom row):
            if shape.maxY == 100:
                if maxRow == self.boardH - 2 and (minCol == 0 or maxCol == self.boardW - 1):
                    return False


        # check this shape:
        #  O
        # OOO
        if shape.id == 4:
            # initial position:
            if shape.maxY == 100:
                if minRow == 0 and (minCol == 0 or maxCol == self.boardW - 1):
                    return False
            # rotated with 90:
            if shape.minY == -200:
                if maxCol == self.boardW - 1 and (minRow == 0 or maxRow == self.boardH - 1):
                    return False
            # rotated with 180:
            if shape.minY == -100:
                if maxRow == self.boardH - 1 and (minCol == 0 or maxCol == self.boardW - 1):
                    return False
            # rotated with 270:
            if shape.maxY == 200:
                if minCol == 0 and (minRow == 0 or maxRow == self.boardH - 1):
                    return False
                
        # check this shape:
        #   O
        #  OO
        # OO
        if shape.id == 5:
            # initial position:
            if shape.maxX == 200 and shape.maxY == 200:
                if maxRow == self.boardH - 1 and maxCol == self.boardW - 1:
                    return False
            # rotated with 90:
            if shape.maxX == 200 and shape.minY == -200:
                if maxRow == self.boardH - 1 and minCol == 0:
                    return False
            # rotated with 180:
            if shape.minX == -200 and shape.minY == -200:
                if minRow == 0 and minCol == 0:
                    return False
            # rotated with 270:
            if shape.minX == -200 and shape.maxY == 200:
                if minRow == 0 and maxCol == self.boardW - 1:
                    return False
                
        # check this shape:
        # OO
        # OOO
        if shape.id == 6:
            # initial position or mirrored and rotated with 90:
            if (shape.maxX == 200 and shape.maxY == 100) or \
               (shape.maxX == 100 and shape.maxY == 200):
                   if minRow == 0 and maxCol == self.boardW - 1:
                       return False
            # rotated with 90 or mirrored and rotated with 180:
            if (shape.maxX == 100 and shape.minY == -200) or \
               (shape.maxX == 200 and shape.minY == -100):
                   if maxRow == self.boardH - 1 and maxCol == self.boardW - 1:
                       return False
            # rotated with 180 or mirrored and rotated with 270:
            if (shape.minX == -200 and shape.minY == -100) or \
               (shape.minX == -100 and shape.minY == -200):
                   if maxRow == self.boardH - 1 and minCol == 0:
                       return False
            # rotated with 270 or mirrored, unrotated:
            if (shape.minX == -100 and shape.maxY == 200) or \
               (shape.minX == -200 and shape.maxY == 100):
                   if minRow == 0 and minCol == 0:
                       return False

        
        # check this shape:
        #  O
        #  OO
        # OO
        if shape.id == 8:
            # initial position or mirrored and rotated with 90:
            if shape.maxX == 200 and shape.maxY == 200:
                if (minRow == 0 and minCol == 0) or \
                   (maxRow == self.boardH - 1 and maxCol == self.boardW - 1) or \
                   (minRow == 0 and maxCol == self.boardW - 1):
                       return False
                    
            # rotated with 90 or mirrored and rotated with 180:
            if shape.maxX == 200 and shape.minY == -200:
                if (maxRow == self.boardH - 1 and minCol == 0) or \
                   (minRow == 0 and maxCol == self.boardW - 1) or \
                   (maxRow == self.boardH - 1 and maxCol == self.boardW - 1):
                       return False           
                
            # rotated with 180 or mirrored and rotated with 270:
            if shape.minX == -200 and shape.minY == -200:
                if (maxRow == self.boardH - 1 and minCol == 0) or \
                   (minRow == 0 and minCol == 0) or \
                   (maxRow == self.boardH - 1 and maxCol == self.boardW - 1):
                       return False
                  
            # rotated with 270 or mirrored, unrotated:
            if shape.minX == -200 and shape.maxY == 200:
                if (maxRow == self.boardH - 1 and minCol == 0) or \
                   (minRow == 0 and minCol == 0) or \
                   (minRow == 0 and maxCol == self.boardW - 1):
                       return False
            
        # check this shape:
        #  OO
        # OO      
        if shape.id == 9:
               # initial position:
            if (shape.maxX == 200 and shape.maxY == 100) or \
               (shape.maxX == 100 and shape.maxY == 200): # mirrored and rotated with 90
                if (minRow == 0 and minCol == 0) or \
                   (maxRow == self.boardH - 1 and maxCol == self.boardW - 1):
                       return False
               # rotated with 90:
            if (shape.maxX == 100 and shape.minY == -200) or \
               (shape.minX == -200 and shape.maxY == 100): # mirrored, unrotated
                if (maxRow == self.boardH - 1 and minCol == 0) or \
                   (minRow == 0 and maxCol == self.boardW - 1):
                       return False
        
        # check this shape:
        #  O
        # OOOO       
        if shape.id == 10:
            # initial position or mirrored, unrotated:
            # corner cases and two special cases (parallel with the bottom row):
            if shape.maxY == 100:
                if minRow == 0 and (minCol == 0 or maxCol == self.boardW - 1):
                    return False
                if maxRow == self.boardH - 2 and (minCol == 0 or maxCol == self.boardW - 1):
                   return False               

            # rotated with 90 or mirrored and rotated with 90:
            # corner cases and two special cases (parallel with the left column):
            if shape.maxX == 100:
                if maxCol == self.boardW - 1 and (minRow == 0 or maxRow == self.boardH - 1):
                    return False
                if minCol == 1 and (minRow == 0 or maxRow == self.boardH - 1):
                  return False                
                
            # rotated with 180 or mirrored and rotated with 180:
            # corner cases and two special cases (parallel with the top row):
            if shape.minY == -100:
                if maxRow == self.boardH - 1 and (minCol == 0 or maxCol == self.boardW - 1):
                    return False
                if minRow == 1 and (minCol == 0 or maxCol == self.boardW - 1):
                   return False                 
                  
            # rotated with 270 and mirrored and rotated with 270:
            # corner cases and two special cases (parallel with the right column):
            if shape.minX == -100:
                if minCol == 0 and (minRow == 0 or maxRow == self.boardH - 1):
                    return False
                if maxCol == self.boardW - 2 and (minRow == 0 or maxRow == self.boardH - 1):
                  return False                 
  

        # check this shape:
        #  OOO
        # OO
        if shape.id == 11:
            # corner cases:
            
            # initial position or
            # rotated with 180 or
            # mirrored and rotated with 90 or
            # mirrored and rotated with 270:
            if (shape.maxX == 300 and shape.maxY == 100) or \
               (shape.minX == -300 and shape.minY == -100) or \
               (shape.maxX == 100 and shape.maxY == 300) or \
               (shape.minX == -100 and shape.minY == -300):
                   if (minRow == 0 and minCol == 0) or \
                      (maxRow == self.boardH - 1 and maxCol == self.boardW - 1):
                          return False
            # rotated with 90 or
            # rotated with 270 or
            # mirrored, unrotated or
            # mirrored and rotated with 180:
            if (shape.maxX == 100 and shape.minY == -300) or \
               (shape.minX == -100 and shape.maxY == 300) or \
               (shape.minX == -300 and shape.maxY == 100) or \
               (shape.maxX == 300 and shape.minY == -100):
                   if (maxRow == self.boardH - 1 and minCol == 0) or \
                      (minRow == 0 and maxCol == self.boardW - 1):
                          return False
                      
            # paralel with edges:
            if shape.maxX == 100 and shape.minY == -300:
                if minRow == 1 and minCol == self.boardW - 3:
                    return False
            
            if shape.minX == -100 and shape.maxY == 300:
                if minRow == 0 and minCol == 1:
                    return False          
         
            if shape.maxX == 100 and shape.maxY == 300:
                if minRow == 0 and maxCol == self.boardW - 2:
                    return False
                
            if shape.minX == -100 and shape.minY == -300:
                if minRow == 1 and minCol == 1:
                    return False

        return True

    
    def validPositions(self, shape):
        pos = []
        for row in range(0, self.boardH):
            for col in range(0, self.boardW):
                if not self.board[row][col] and \
                   self.checkPos(shape, row, col):
                    pos.append([row, col])
        return pos

        
    def put(self, shape, row, col):
        for ball in shape.balls:
            rowCurr = int(row - ball[1] / 100)
            colCurr = int(col + ball[0] / 100)
            self.board[rowCurr][colCurr] = True

    
    def pop(self, shape, row, col):
        for ball in shape.balls:
            rowCurr = int(row - ball[1] / 100)
            colCurr = int(col + ball[0] / 100)
            self.board[rowCurr][colCurr] = False