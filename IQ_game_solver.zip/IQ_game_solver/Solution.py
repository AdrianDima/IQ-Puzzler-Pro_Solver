#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""

#file  -- Solution.py --

from Board import *

import copy 
    
class Solution:
    
    def __init__(self):
        self.playingShapes = []
        self.playingShapesInitialValidPos = []
        self.board = Board()
        self.sol = []

        
    # method to build all possible positions of a shape on the board
    def shapePositions(self, shape):
        possiblePositions = []
        possiblePositions.append(shape)
        # this shape has only 4 possible positions, although it is not symmetrical:
        #  OO
        # OO 
        if shape.id == 9:
            shapeCopy = copy.deepcopy(possiblePositions[-1])
            shapeCopy.rotate() # 90
            possiblePositions.append(shapeCopy)
            
            shapeCopy = copy.deepcopy(possiblePositions[0])
            shapeCopy.mirror()
            possiblePositions.append(shapeCopy)
            
            shapeCopy = copy.deepcopy(possiblePositions[-1])
            shapeCopy.rotate() # 90
            possiblePositions.append(shapeCopy)
        else:
            for _ in range(3):
                shapeCopy = copy.deepcopy(possiblePositions[-1])
                shapeCopy.rotate() # 90, 180, 270
                possiblePositions.append(shapeCopy)
    
            if not shape.symmetrical:
                shapeCopy = copy.deepcopy(possiblePositions[-1])
                shapeCopy.mirror()
                possiblePositions.append(shapeCopy)
                for _ in range(3):
                    shapeCopy = copy.deepcopy(possiblePositions[-1])
                    shapeCopy.rotate() # 90, 180, 270
                    possiblePositions.append(shapeCopy)
        
        return possiblePositions

    
    # method to create a list with the playing shapes, for every shape
    # with all possible positions:
    def buildPlayingShapes(self, shapeStorage, initialShapes):
        initialShapesId = []
        # this additional step is necessary for the visual interface:
        for shape in initialShapes:
            initialShapesId.append(shape.id)
        
        for shape in shapeStorage.shapes:
            if shape.id not in initialShapesId:
                self.playingShapes.append(self.shapePositions(shape))
    
                    
    def validPositionsAtTheBeginningOfTheGame(self):
        for shapePossiblePositions in self.playingShapes:
            temp = []
            for shapePosition in shapePossiblePositions:
                temp.append(self.board.validPositions(shapePosition))
            self.playingShapesInitialValidPos.append(temp)
    
    
    def validPositionsWhileSolving(self, k, index, shape):
        currentValidPositions = []
        for pos in self.playingShapesInitialValidPos[k][index]:
            if self.board.checkAdjacentCellsForOverlap(shape, pos[0], pos[1]):
                currentValidPositions.append(pos)
        return currentValidPositions


    def checkSolution(self):
        for row in range(0, self.board.boardH):
            for col in range(0, self.board.boardW):
                if not self.board.board[row][col]:
                    return False
        return True


    def back(self, k):
        if k == len(self.playingShapes) and self.checkSolution():
            raise Exception("The solution was found.")
        else:
            index = 0
            for shape in self.playingShapes[k]:
                # list of valid positions:
                pos = self.validPositionsWhileSolving(k, index, shape)
                for p in pos:
                    self.board.put(shape, p[0], p[1])
                    self.sol.append([shape, p[0], p[1]])
                    self.back(k + 1)
                    self.board.pop(shape, p[0], p[1])
                    self.sol.pop()
                index += 1