#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb  7 13:39:58 2025

@author: adrian
"""
from ShapeStorage import *
from Board import *
from Solution import *

import sys
sys.setrecursionlimit(10000)

import turtle

class Game:
    
    def __init__(self):
        # initial shapes already placed on the board at the beginning of the game
        self.shapes = []
        self.shapeYPos = []
        self.shapeXPos = []
        # ss - an object of class ShapeStorage, which contains all
        # possible shapes in the default position
        self.ss = ShapeStorage(12)
        self.solution = Solution()


    # method to build the board with the initial shapes already placed
    # on the board at the beginning of the game
    # having the visual interface, this method is no longer used
    def insertShape(self, index, shape, mirrored, rotation, row, col):
        # mirrored = True / False,  rotation = 90, 180, 270
        if index != None:
            s = self.ss.shapes[index]
        else:
            s = shape
        if mirrored:
            s.mirror()
        if rotation:
            s.rotation = rotation
            for _ in range(int(rotation / 90)):
                s.rotate()
        self.shapes.append(s)
        self.shapeYPos.append(col)
        self.shapeXPos.append(row)
        self.solution.board.put(s, row, col)
        
        
    def solve(self):
        self.solution.buildPlayingShapes(self.ss, self.shapes)
        self.solution.validPositionsAtTheBeginningOfTheGame()
        
        try:
            self.solution.back(0)
            return True
        except:
            return False

    
    def printSolution(self, t, XORIG, YORIG, HEIGHT):
        # print the initial shapes already placed on the board at the beginning of the game:
        for index in range(len(self.shapes)):
            self.shapes[index].draw(self.shapeYPos[index] * 100, HEIGHT - (self.shapeXPos[index] + 1) * 100, t, XORIG, YORIG)
        # print the solution (the rest of the shapes):
        for s in self.solution.sol:
            s[0].draw(s[2] * 100, HEIGHT - (s[1] + 1) * 100, t, XORIG, YORIG)


    def drawSolution(self):
        turtle.tracer(0, 0)
        WIDTH, HEIGHT = 1100, 500
        screen = turtle.Screen()
        screen.setup(WIDTH, HEIGHT)
    
        XORIG, YORIG = -WIDTH / 2 + 50, -HEIGHT / 2 + 50
        t = turtle.Turtle()
        t.speed_value = 0
        t.hideturtle()
        
        self.printSolution(t, XORIG, YORIG, HEIGHT)
        
        turtle.update()
        turtle.done()
        turtle.mainloop()

# game = Game()

# *****************************************************************************
# game #16:
# game.insertShape(3, None, False, 0, 4, 0)
# game.insertShape(11, None, False, 90, 0, 0)
# game.insertShape(2, None, False, 180, 0, 2)
# game.insertShape(10, None, True, 90, 3, 3)
# game.insertShape(7, None, False, 0, 1, 4)
# game.insertShape(5, None, False, 0, 4, 3)

# *****************************************************************************
# game #30:
# game.insertShape(3, None, False, 90, 0, 0)
# game.insertShape(7, None, False, 180, 0, 4)
# game.insertShape(6, None, True, 180, 0, 5)
# game.insertShape(4, None, False, 90, 1, 7)

# *****************************************************************************
# game #40:
# game.insertShape(6, None, True, 90, 2, 0)
# game.insertShape(10, None, False, 180, 2, 5)

# game.solve()
# game.drawSolution()